public class Context {
    private ICalculator calculator;

    public Context ( ICalculator operation ){
        calculator = operation;
    }

    public double execute( double ... num ){
        return calculator.calculate (num);

    }


}
