public class Main {
    public static void main(String[] args)
    {
        double num1= 18;
        double num2= 3;
        //double num3 =3;
        //double num4 =6;
        Context myCalculator = new Context ( new Division());
        double result = myCalculator.execute(num1,num2);
        System.out.println("Result is " + result );

    }



}
