public class Division implements ICalculator{
    @Override
    public double calculate(double ... num) {
        try {
            double x = 1;
            double y = num[0] / x;
            for(int i = 1; i < num.length; i++ ){
                y= y/num[i] ;


            }
            return y;
        } catch (IllegalArgumentException error) {
            System.out.println("Error exception : " + error);
            return 0;
        }

    }
}