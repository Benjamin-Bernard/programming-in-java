public class Multiplication implements ICalculator{
    @Override
    public double calculate ( double ... num){
        double x = 1;
        for(int i = 0; i < num.length; i++ ){
            x = num[i] * x ;
        }
        return x;
    }

}

