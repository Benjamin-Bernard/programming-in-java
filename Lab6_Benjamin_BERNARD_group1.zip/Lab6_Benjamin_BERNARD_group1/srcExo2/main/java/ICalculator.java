public interface ICalculator {
    double calculate(double ... num);

}
