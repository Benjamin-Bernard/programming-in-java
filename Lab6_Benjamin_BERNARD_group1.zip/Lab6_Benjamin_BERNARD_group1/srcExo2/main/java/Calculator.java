public class Calculator {
    private ICalculator calc;

    public Calculator ( ICalculator op ){
        calc = op;
    }

    public double launch( double ... num ){
        return calc.calculate (num);

    }


}
