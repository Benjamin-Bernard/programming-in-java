public class Substraction implements ICalculator{
    @Override
    public double calculate ( double ... num ){
        double x = num[0];
        for(int i = 1; i < num.length; i++ ){
            x = x - num[i] ;
        }
        return x;
    }
}

