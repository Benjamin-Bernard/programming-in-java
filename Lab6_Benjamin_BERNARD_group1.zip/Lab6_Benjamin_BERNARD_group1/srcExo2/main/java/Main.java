public class Main {
    public static void main(String[] args)
    {
        double num1= 18;
        double num2= 2;
        double num3 =3;
        double num4 =6;
        Calculator calculator = new Calculator ( new Substraction());
        Calculator calculator2 = new Calculator ( new Addition());
        Calculator calculator3 = new Calculator ( new Multiplication());
        Calculator calculator4 = new Calculator ( new Division());
        double result = calculator.launch(num1,num2, num3, num4);
        double result2 = calculator2.launch(num1,num2, num3, num4);
        double result3 = calculator3.launch(num1,num2, num3, num4);
        double result4 = calculator4.launch(num1,num2, num3, num4);
        System.out.println("Result is " + result );
        System.out.println("Result is " + result2 );
        System.out.println("Result is " + result3 );
        System.out.println("Result is " + result4 );

    }



}
