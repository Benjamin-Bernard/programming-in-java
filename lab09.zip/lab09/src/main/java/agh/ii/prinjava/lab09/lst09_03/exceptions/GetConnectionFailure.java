package agh.ii.prinjava.lab09.lst09_03.exceptions;

public class GetConnectionFailure extends RuntimeException {
}
